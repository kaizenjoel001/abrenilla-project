<!DOCTYPE html>
<html>
<head>
  <title><?= esc($title ?? 'Resolutions') ?></title>
</head>
<body>
  <?= $this->renderSection('content') ?>
</body>
</html>
